import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ActivityIndicator, SafeAreaView, TouchableOpacity, Switch } from 'react-native';
import { Database } from '@nozbe/watermelondb';
import { DatabaseProvider } from '@nozbe/watermelondb/react';

import { initializeDatabase } from './database';
import { Dashboard } from './src/components/Dashboard';
import { AddTransaction } from './src/components/AddTransaction';
import { ImportButton } from './src/components/ImportButton';
import { syncPriceData, backfillHistoricalPrices } from './database/utils/syncEngine';
import { NewsScreen } from './src/components/NewsScreen';
import { AdvancedAnalytics } from './src/components/AdvancedAnalytics';
import { MarketAutomation } from './src/components/MarketAutomation';

const DBProvider = DatabaseProvider as any;

const NAV_THEMES = {
  light: {
    bg: '#f8f9fa',
    panel: '#ffffff',
    panel2: '#f1f3f5',
    tabBar: '#ffffff',
    line: 'rgba(0, 0, 0, 0.08)',
    text: '#212529',
    muted: '#6c757d',
    activeBlue: '#A9A9A9',
  },
  dark: {
    bg: '#0f1115',
    panel: '#161920',
    panel2: '#212631',
    tabBar: '#161920',
    line: 'rgba(255, 255, 255, 0.08)',
    text: '#f8f9fa',
    muted: '#98a2b3',
    activeBlue: '#4b5563', 
  }
};

export default function App() {
  const [dbInstance, setDbInstance] = useState<Database | null>(null);
  const [activeTab, setActiveTab] = useState<string>('DASHBOARD');
  
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  
  const currentTheme = isDarkMode ? NAV_THEMES.dark : NAV_THEMES.light;

  useEffect(() => {
    async function setup() {
      try {
        const db = await initializeDatabase();
        setDbInstance(db);
      } catch (error) {
        console.error("Critical error starting app database:", error);
      }
    }
    setup();
  }, []);

  if (!dbInstance) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: '#0f1115' }]}>
        <ActivityIndicator size="large" color="#4b5563" />
        <Text style={[styles.loadingText, { color: '#98a2b3' }]}>Securing Vault Database...</Text>
      </View>
    );
  }

  const renderScreenContent = () => {
    switch (activeTab) {
      case 'DASHBOARD':
        return <Dashboard isDarkMode={isDarkMode} />;
      case 'ANALYTICS':
        return <AdvancedAnalytics isDarkMode={isDarkMode} />;
      case 'AUTOMATION':
        return <MarketAutomation isDarkMode={isDarkMode} />;
      case 'TRANSACTIONS':
        return <AddTransaction />;
      case 'NEWS':
        return <NewsScreen currentTheme={currentTheme} />;
      case 'SETTINGS':
        return (
          <View style={[styles.settingsScreen, { backgroundColor: currentTheme.bg }]}>
            <Text style={[styles.settingsTitle, { color: currentTheme.text }]}>Settings</Text>
            
            <View style={[styles.switchRow, { borderBottomColor: currentTheme.line }]}>
              <Text style={[styles.switchLabel, { color: currentTheme.text }]}>Dark Mode Display</Text>
              <Switch
                value={isDarkMode}
                onValueChange={(val) => setIsDarkMode(val)}
                trackColor={{ false: '#767577', true: currentTheme.activeBlue }}
                thumbColor={isDarkMode ? '#ffffff' : '#f4f3f4'}
              />
            </View>

            <Text style={[styles.sectionLabel, { color: currentTheme.muted, marginTop: 24 }]}>Data Synchronization</Text>
            
            <TouchableOpacity
              style={[styles.primaryBtn, { backgroundColor: currentTheme.panel2, borderColor: currentTheme.line }, isSyncing && { opacity: 0.6 }]}
              onPress={() => { setIsSyncing(true); syncPriceData().finally(() => setIsSyncing(false)); }}
              disabled={isSyncing}
            >
              <Text style={[styles.primaryBtnText, { color: currentTheme.text }]}>
                {isSyncing ? 'Syncing Real-time Prices...' : 'Refresh Current Prices'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.primaryBtn, { backgroundColor: currentTheme.panel2, borderColor: currentTheme.line }, isSyncing && { opacity: 0.6 }]}
              onPress={async () => {
                setIsSyncing(true);
                try { await backfillHistoricalPrices(); }
                catch (error) { console.error("Sync history failed:", error); }
                finally { setIsSyncing(false); }
              }}
              disabled={isSyncing}
            >
              <Text style={[styles.primaryBtnText, { color: currentTheme.text }]}>
                {isSyncing ? 'Downloading History Vectors...' : 'Download Historical Price Vectors (365D)'}
              </Text>
            </TouchableOpacity>

            <Text style={[styles.sectionLabel, { color: currentTheme.muted, marginTop: 24 }]}>Data Administration</Text>
            <View style={{ marginTop: 8 }}>
              <ImportButton />
            </View>
          </View>
        );
      default:
        return <Dashboard isDarkMode={isDarkMode} />;
    }
  };

  return (
    <DBProvider database={dbInstance}>
      <SafeAreaView style={[styles.container, { backgroundColor: currentTheme.bg }]}>
        
        <View style={styles.screenWrapper}>
          {renderScreenContent()}
        </View>

        <View style={[styles.tabBarContainer, { backgroundColor: currentTheme.tabBar, borderTopColor: currentTheme.line }]}>
          {[
            { id: 'DASHBOARD', label: 'Dashboard', icon: '📊' },
            { id: 'ANALYTICS', label: 'Analytics', icon: '📈' },
            { id: 'AUTOMATION', label: 'Auto', icon: '🤖' },
            { id: 'TRANSACTIONS', label: 'Action', icon: '💸' },
            { id: 'NEWS', label: 'News', icon: '🌐' },
            { id: 'SETTINGS', label: 'Settings', icon: '⚙️' }
          ].map((tab) => {
            const isTabFocused = activeTab === tab.id;
            return (
              <TouchableOpacity
                key={tab.id}
                onPress={() => setActiveTab(tab.id)}
                activeOpacity={0.7}
                style={[
                  styles.tabButton, 
                  isTabFocused && { backgroundColor: isDarkMode ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.03)' }
                ]}
              >
                <Text style={styles.tabIcon}>{tab.icon}</Text>
                <Text style={[
                  styles.tabLabel, 
                  { color: isTabFocused ? currentTheme.text : currentTheme.muted }
                ]}>
                  {tab.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

      </SafeAreaView>
    </DBProvider>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  screenWrapper: { flex: 1 },
  tabBarContainer: { 
    flexDirection: 'row', 
    height: 64, 
    borderTopWidth: 1, 
    paddingHorizontal: 8,
    paddingBottom: 4,
    alignItems: 'center',
    justifyContent: 'space-around'
  },
  tabButton: { 
    flex: 1,
    alignItems: 'center', 
    justifyContent: 'center',
    paddingVertical: 6,
    marginHorizontal: 4,
    borderRadius: 12
  },
  tabIcon: { fontSize: 18, marginBottom: 2 },
  tabLabel: { fontSize: 11, fontWeight: '600' },
  fallbackScreen: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  fallbackText: { fontSize: 14, fontWeight: '600' },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingText: { marginTop: 14, fontSize: 13, fontWeight: '500' },
  settingsScreen: { flex: 1, padding: 24 },
  settingsTitle: { fontSize: 28, fontWeight: '800', marginBottom: 16, marginTop: 10 },
  sectionLabel: { fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 },
  switchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 16, borderBottomWidth: 1 },
  switchLabel: { fontSize: 16, fontWeight: '600' },
  primaryBtn: { paddingVertical: 14, paddingHorizontal: 18, borderRadius: 12, borderWidth: 1, marginBottom: 12 },
  primaryBtnText: { fontSize: 14, fontWeight: '600', textAlign: 'left' },
});