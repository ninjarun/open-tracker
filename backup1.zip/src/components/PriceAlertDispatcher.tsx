import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ScrollView } from 'react-native';
import { useDatabase } from '@nozbe/watermelondb/hooks';
import { PriceAlert, PriceHistory } from '../../database/models';
import { checkPriceAlerts, createPriceAlert, disablePriceAlert, listPriceAlerts, PriceAlertRow, AlertDirection } from '../utils/priceAlerts';
import { configureLocalNotifications } from '../utils/notifications';

type Theme = {
  panel: string;
  panel2: string;
  text: string;
  muted: string;
  line: string;
  green: string;
  red: string;
  blue: string;
};

type Props = { theme: Theme };

type SearchCoin = {
  id: string;
  symbol: string;
  name: string;
};

export function PriceAlertDispatcher({ theme }: Props) {
  const database = useDatabase();
  
  // Search and selection states
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [suggestions, setSuggestions] = useState<SearchCoin[]>([]);
  const [selectedCoin, setSelectedCoin] = useState<SearchCoin | null>(null);
  const [showDropdown, setShowDropdown] = useState<boolean>(false);

  const [direction, setDirection] = useState<AlertDirection>('ABOVE');
  const [threshold, setThreshold] = useState<string>('');
  const [alerts, setAlerts] = useState<PriceAlertRow[]>([]);
  const [lastCheck, setLastCheck] = useState<string>('Never');

  async function refreshAlerts() {
    setAlerts(await listPriceAlerts(database));
  }

  async function runLocalCheck() {
    await configureLocalNotifications();
    const count = await checkPriceAlerts(database);
    setLastCheck(`${new Date().toLocaleTimeString()} (${count} triggered)`);
    await refreshAlerts();
  }

  // Handle live autocomplete search fetching from global library
  useEffect(() => {
    if (searchQuery.trim().length < 2) {
      setSuggestions([]);
      return;
    }

    const delayDebounce = setTimeout(async () => {
      try {
        const response = await fetch(`https://api.coingecko.com/api/v3/search?query=${searchQuery}`);
        const data = await response.json();
        if (data && Array.isArray(data.coins)) {
          // Map to match our SearchCoin interface format
          const formatted = data.coins.slice(0, 6).map((c: any) => ({
            id: c.id,
            symbol: c.symbol.toUpperCase(),
            name: c.name,
          }));
          setSuggestions(formatted);
        }
      } catch (err) {
        console.error('Failed to query autocomplete items:', err);
      }
    }, 400); // 400ms debounce to respect API rate limits

    return () => clearTimeout(delayDebounce);
  }, [searchQuery]);

  useEffect(() => {
    refreshAlerts();
    const alertSub = database.get<PriceAlert>('price_alerts').query().observe().subscribe(refreshAlerts);

    return () => {
      alertSub.unsubscribe();
    };
  }, [database]);

  async function onCreateAlert() {
    const numericThreshold = Number(threshold);
    if (!selectedCoin || !Number.isFinite(numericThreshold) || numericThreshold <= 0) return;

    await configureLocalNotifications();
    
    // Pass everything down cleanly to our watch-shell handler
    await createPriceAlert(database, {
      assetId: selectedCoin.id,
      ticker: selectedCoin.symbol,
      name: selectedCoin.name,
      direction,
      threshold: numericThreshold,
    });

    // Reset interface inputs
    setThreshold('');
    setSearchQuery('');
    setSelectedCoin(null);
    await runLocalCheck();
  }

  return (
    <View style={[styles.card, { backgroundColor: theme.panel, borderColor: theme.line }]}> 
      <Text style={[styles.title, { color: theme.text }]}>Price Alert Dispatcher</Text>
      <Text style={[styles.subtitle, { color: theme.muted }]}>Set a threshold alert for any coin on the global market.</Text>

      {/* Autocomplete Input Section */}
      <Text style={[styles.label, { color: theme.muted }]}>Search Global Asset</Text>
      <View style={styles.searchContainer}>
        <TextInput
          value={selectedCoin ? `${selectedCoin.name} (${selectedCoin.symbol})` : searchQuery}
          onChangeText={(text) => {
            if (selectedCoin) setSelectedCoin(null); // Clear selection if typing again
            setSearchQuery(text);
            setShowDropdown(true);
          }}
          onFocus={() => setShowDropdown(true)}
          placeholder="Type e.g. Solana, Cardano, BTC..."
          placeholderTextColor={theme.muted}
          style={[styles.input, { backgroundColor: theme.panel2, borderColor: theme.line, color: theme.text, marginTop: 0 }]}
        />

        {/* Dropdown Suggestions List */}
        {showDropdown && suggestions.length > 0 && (
          <View style={[styles.dropdown, { backgroundColor: theme.panel2, borderColor: theme.line }]}>
            {suggestions.map((coin) => (
              <TouchableOpacity
                key={coin.id}
                style={[styles.dropdownItem, { borderBottomColor: theme.line }]}
                onPress={() => {
                  setSelectedCoin(coin);
                  setShowDropdown(false);
                }}
              >
                <Text style={[styles.coinText, { color: theme.text }]}>
                  {coin.name} <Text style={{ color: theme.muted, fontWeight: '500' }}>({coin.symbol})</Text>
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>

      <Text style={[styles.label, { color: theme.muted, marginTop: 14 }]}>Trigger Condition</Text>
      <View style={styles.directionRow}>
        {(['ABOVE', 'BELOW'] as AlertDirection[]).map(option => (
          <TouchableOpacity
            key={option}
            onPress={() => setDirection(option)}
            style={[
              styles.directionButton,
              { backgroundColor: theme.panel2 },
              direction === option && { backgroundColor: option === 'ABOVE' ? theme.green : theme.red },
            ]}
          >
            <Text style={[styles.directionText, { color: direction === option ? '#fff' : theme.text }]}>{option}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={[styles.label, { color: theme.muted }]}>Threshold Price (USD)</Text>
      <TextInput
        value={threshold}
        onChangeText={setThreshold}
        keyboardType="decimal-pad"
        placeholder="e.g. 145.50"
        placeholderTextColor={theme.muted}
        style={[styles.input, { backgroundColor: theme.panel2, borderColor: theme.line, color: theme.text }]}
      />

      <TouchableOpacity 
        style={[
          styles.primaryButton, 
          { backgroundColor: selectedCoin && threshold ? theme.blue : theme.panel2, opacity: selectedCoin && threshold ? 1 : 0.5 }
        ]} 
        onPress={onCreateAlert}
        disabled={!selectedCoin || !threshold}
      >
        <Text style={[styles.primaryButtonText, { color: selectedCoin && threshold ? '#fff' : theme.muted }]}>Create Global Alert</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.secondaryButton, { borderColor: theme.line }]} onPress={runLocalCheck}>
        <Text style={[styles.secondaryButtonText, { color: theme.text }]}>Run Local Check Now</Text>
      </TouchableOpacity>

      <Text style={[styles.lastCheck, { color: theme.muted }]}>Last check: {lastCheck}</Text>

      <Text style={[styles.activeTitle, { color: theme.text }]}>Active Alerts</Text>
      {alerts.length === 0 ? (
        <Text style={[styles.empty, { color: theme.muted }]}>No price alerts yet.</Text>
      ) : alerts.map(alert => (
        <View key={alert.id} style={[styles.alertRow, { borderBottomColor: theme.line }]}> 
          <View>
            <Text style={[styles.alertTicker, { color: theme.text }]}>{alert.ticker}</Text>
            <Text style={[styles.alertMeta, { color: theme.muted }]}> 
              {alert.direction} ${alert.threshold.toLocaleString()} · now ${alert.currentPrice.toLocaleString(undefined, { maximumFractionDigits: 4 })}
            </Text>
          </View>
          <TouchableOpacity disabled={!alert.enabled} onPress={() => disablePriceAlert(database, alert.id).then(refreshAlerts)}>
            <Text style={[styles.alertStatus, { color: alert.enabled ? theme.green : theme.muted }]}> 
              {alert.enabled ? 'ON' : 'DONE'}
            </Text>
          </TouchableOpacity>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderRadius: 20, padding: 20, borderWidth: 1, marginBottom: 16 },
  title: { fontSize: 18, fontWeight: '900' },
  subtitle: { fontSize: 12, fontWeight: '600', marginTop: 4, marginBottom: 16 },
  label: { fontSize: 11, fontWeight: '900', textTransform: 'uppercase', marginBottom: 8, marginTop: 10 },
  searchContainer: { zIndex: 10, position: 'relative' },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, fontWeight: '700', marginTop: 4 },
  dropdown: { position: 'absolute', top: 52, left: 0, right: 0, borderWidth: 1, borderRadius: 12, zIndex: 99, elevation: 5, shadowRadius: 4, shadowOpacity: 0.1, shadowOffset: { width: 0, height: 2 } },
  dropdownItem: { paddingVertical: 12, paddingHorizontal: 16, borderBottomWidth: 1 },
  coinText: { fontSize: 14, fontWeight: '700' },
  directionRow: { flexDirection: 'row', marginBottom: 10 },
  directionButton: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 12, marginRight: 8 },
  directionText: { fontWeight: '900' },
  primaryButton: { borderRadius: 12, paddingVertical: 13, alignItems: 'center', marginTop: 16 },
  primaryButtonText: { fontWeight: '900' },
  secondaryButton: { borderRadius: 12, paddingVertical: 12, alignItems: 'center', marginTop: 10, borderWidth: 1 },
  secondaryButtonText: { fontWeight: '900' },
  lastCheck: { fontSize: 12, fontWeight: '700', marginTop: 10 },
  activeTitle: { fontSize: 15, fontWeight: '900', marginTop: 22, marginBottom: 6 },
  empty: { fontSize: 13, fontWeight: '600', paddingVertical: 10 },
  alertRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1 },
  alertTicker: { fontSize: 15, fontWeight: '900' },
  alertMeta: { fontSize: 12, fontWeight: '600', marginTop: 2 },
  alertStatus: { fontSize: 12, fontWeight: '900' },
});