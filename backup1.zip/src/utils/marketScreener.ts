export type ScreenerAsset = {
  assetId: string; // e.g., 'bitcoin'
  ticker: string;  // e.g., 'BTC'
  name: string;    // e.g., 'Bitcoin'
  type: string;
  currentPrice: number;
  price24hAgo: number;
  change24h: number;
  changePercent24h: number;
};

// We drop the Database dependency here because we are screening the global market!
export async function buildLocalMarketScreener(): Promise<{
  gainers: ScreenerAsset[];
  losers: ScreenerAsset[];
  all: ScreenerAsset[];
}> {
  try {
    // Fetching the top 250 coins by market cap
    const response = await fetch(
      'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=1&sparkline=false&price_change_percentage=24h'
    );
    const data = await response.json();

    if (!Array.isArray(data)) {
      return { gainers: [], losers: [], all: [] };
    }

    const all: ScreenerAsset[] = data.map((coin: any) => {
      const currentPrice = coin.current_price || 0;
      const changePercent24h = coin.price_change_percentage_24h || 0;
      // Reconstruct historical context mathematically from the response data
      const price24hAgo = currentPrice / (1 + changePercent24h / 100);
      const change24h = currentPrice - price24hAgo;

      return {
        assetId: coin.id,
        ticker: coin.symbol.toUpperCase(),
        name: coin.name,
        type: 'crypto',
        currentPrice,
        price24hAgo,
        change24h,
        changePercent24h,
      };
    });

    // Sort out our top performers
    const gainers = [...all].sort((a, b) => b.changePercent24h - a.changePercent24h).slice(0, 5);
    const losers = [...all].sort((a, b) => a.changePercent24h - b.changePercent24h).slice(0, 5);

    return { gainers, losers, all };
  } catch (error) {
    console.error('Failed to fetch global market data:', error);
    return { gainers: [], losers: [], all: [] };
  }
}