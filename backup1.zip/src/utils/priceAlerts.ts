import { Database } from '@nozbe/watermelondb';
import { Q } from '@nozbe/watermelondb';
import { Asset, PriceAlert, PriceHistory } from '../../database/models';
import { dispatchLocalPriceAlertNotification } from './notifications';

export type AlertDirection = 'ABOVE' | 'BELOW';

export type PriceAlertRow = {
  id: string;
  assetId: string;
  ticker: string;
  name: string;
  direction: AlertDirection;
  threshold: number;
  enabled: boolean;
  triggeredAt?: Date;
  currentPrice: number;
};

async function getLatestPrice(database: Database, assetId: string): Promise<number> {
  const rows = await database.get<PriceHistory>('price_history')
    .query(Q.where('asset_id', assetId), Q.sortBy('timestamp', Q.desc), Q.take(1))
    .fetch();

  return rows[0] ? Number(rows[0].price || 0) : 0;
}

export async function listPriceAlerts(database: Database): Promise<PriceAlertRow[]> {
  const alerts = await database.get<PriceAlert>('price_alerts')
    .query(Q.sortBy('created_at', Q.desc))
    .fetch();

  return Promise.all(alerts.map(async alert => {
    const asset = await alert.asset.fetch() as Asset;
    const currentPrice = await getLatestPrice(database, asset.id);

    return {
      id: alert.id,
      assetId: asset.id,
      ticker: asset.ticker,
      name: asset.name,
      direction: alert.direction,
      threshold: alert.threshold,
      enabled: alert.enabled,
      triggeredAt: alert.triggeredAt,
      currentPrice,
    };
  }));
}

// export async function createPriceAlert(database: Database, params: {
//   assetId: string;
//   direction: AlertDirection;
//   threshold: number;
// }): Promise<void> {
//   const asset = await database.get<Asset>('assets').find(params.assetId);

//   await database.write(async () => {
//     await database.get<PriceAlert>('price_alerts').create((alert: any) => {
//       alert.asset.set(asset);
//       alert.direction = params.direction;
//       alert.threshold = Number(params.threshold);
//       alert.enabled = true;
//       alert.createdAt = new Date();
//       alert.updatedAt = new Date();
//     });
//   });
// }
export async function createPriceAlert(database: Database, params: {
  assetId: string;       // global coin id: e.g. 'solana'
  ticker: string;        // e.g. 'SOL'
  name: string;          // e.g. 'Solana'
  direction: AlertDirection;
  threshold: number;
}): Promise<void> {
  
  await database.write(async () => {
    // 1. Ensure the asset exists in our local dictionary table so the relation doesn't break
    let assetRow;
    try {
      assetRow = await database.get<Asset>('assets').find(params.assetId);
    } catch {
      // Asset doesn't exist in our portfolio ledger yet! Create a watch-only placeholder row
      assetRow = await database.get<Asset>('assets').create((newAsset: any) => {
        newAsset._raw.id = params.assetId; // Lock the IDs together
        newAsset.ticker = params.ticker;
        newAsset.name = params.name;
        newAsset.type = 'crypto';
      });
    }

    // 2. Create the price alert exactly like before
    await database.get<PriceAlert>('price_alerts').create((alert: any) => {
      alert.asset.set(assetRow);
      alert.direction = params.direction;
      alert.threshold = Number(params.threshold);
      alert.enabled = true;
      alert.createdAt = new Date();
      alert.updatedAt = new Date();
    });
  });
}

export async function disablePriceAlert(database: Database, alertId: string): Promise<void> {
  const alert = await database.get<PriceAlert>('price_alerts').find(alertId);

  await database.write(async () => {
    await alert.update((record: any) => {
      record.enabled = false;
      record.updatedAt = new Date();
    });
  });
}

export async function checkPriceAlerts(database: Database): Promise<number> {
  const alerts = await database.get<PriceAlert>('price_alerts')
    .query(Q.where('enabled', true))
    .fetch();

  let triggered = 0;

  for (const alert of alerts) {
    const asset = await alert.asset.fetch() as Asset;
    const currentPrice = await getLatestPrice(database, asset.id);
    if (currentPrice <= 0) continue;

    const direction = alert.direction;
    const threshold = Number(alert.threshold || 0);
    const breached = direction === 'ABOVE'
      ? currentPrice >= threshold
      : currentPrice <= threshold;

    if (!breached) continue;

    await dispatchLocalPriceAlertNotification({
      ticker: asset.ticker,
      direction,
      threshold,
      currentPrice,
    });

    await database.write(async () => {
      await alert.update((record: any) => {
        record.enabled = false;
        record.triggeredAt = new Date();
        record.updatedAt = new Date();
      });
    });

    triggered += 1;
  }

  return triggered;
}
